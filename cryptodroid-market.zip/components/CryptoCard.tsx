import React, { memo } from 'react';
import { CoinData, Currency } from '../types';
import PriceChart from './PriceChart';
import { ArrowUpRight, ArrowDownRight, Bitcoin, Cpu, Disc } from 'lucide-react';
import { formatPrice } from '../services/cryptoService';

interface CryptoCardProps {
  coin: CoinData;
  currency: Currency;
}

const CryptoCard: React.FC<CryptoCardProps> = memo(({ coin, currency }) => {
  const isPositive = coin.change24h >= 0;

  const renderIcon = () => {
    switch (coin.symbol) {
      case 'BTC': return <Bitcoin className="w-8 h-8 text-yellow-500" />;
      case 'ETH': return <Cpu className="w-8 h-8 text-blue-500" />; // Abstract representation
      case 'XRP': return <Disc className="w-8 h-8 text-white" />;
      default: return <div className="w-8 h-8 rounded-full bg-gray-500" />;
    }
  };

  return (
    <div className="bg-android-surface rounded-3xl p-5 mb-4 shadow-lg border border-slate-700/50">
      <div className="flex justify-between items-center mb-4">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-slate-700/50 rounded-2xl">
            {renderIcon()}
          </div>
          <div>
            <h3 className="font-bold text-lg tracking-wide">{coin.name}</h3>
            <span className="text-xs text-slate-400 font-medium">{coin.symbol}/{currency}</span>
          </div>
        </div>
        <div className="text-right">
          <div className="text-xl font-bold font-mono">
            {formatPrice(coin.currentPrice, currency)}
          </div>
          <div className={`flex items-center justify-end text-sm font-semibold ${isPositive ? 'text-android-accent' : 'text-android-danger'}`}>
            {isPositive ? <ArrowUpRight size={16} /> : <ArrowDownRight size={16} />}
            <span>{Math.abs(coin.change24h).toFixed(2)}%</span>
          </div>
        </div>
      </div>
      
      {/* Chart */}
      <div className="mt-2">
        <PriceChart data={coin.history} color={coin.symbol} isPositive={isPositive} currency={currency} />
      </div>
    </div>
  );
});

export default CryptoCard;