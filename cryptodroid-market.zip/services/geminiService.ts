import { GoogleGenAI, Type } from "@google/genai";
import { CoinData, MarketAnalysis, Currency } from "../types";
import { CURRENCY_SYMBOLS } from "./cryptoService";

const apiKey = process.env.API_KEY || '';

// Initialize Gemini
const ai = new GoogleGenAI({ apiKey });

export const analyzeMarket = async (coins: CoinData[], currency: Currency): Promise<MarketAnalysis> => {
  if (!apiKey) {
    return {
      sentiment: 'neutral',
      summary: 'Clave de API no configurada. Configure process.env.API_KEY para obtener análisis en vivo.',
      keyLevels: 'N/A'
    };
  }

  const symbol = CURRENCY_SYMBOLS[currency];

  const prompt = `
    Actúa como un analista financiero experto en criptomonedas.
    Analiza los siguientes datos de mercado actuales (Precios obtenidos directamente del par ${currency}):
    ${coins.map(c => {
      // Prices are already in the target currency
      return `${c.name} (${c.symbol}): ${symbol}${c.currentPrice.toFixed(2)} (Cambio 24h: ${c.change24h}%)`;
    }).join('\n')}
    
    Proporciona un resumen breve del mercado en Español, el sentimiento general (bullish, bearish, o neutral), y niveles clave de soporte/resistencia aproximados (menciona los precios en ${currency}).
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            sentiment: { type: Type.STRING, enum: ['bullish', 'bearish', 'neutral'] },
            summary: { type: Type.STRING },
            keyLevels: { type: Type.STRING }
          },
          required: ['sentiment', 'summary', 'keyLevels']
        }
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from Gemini");
    
    return JSON.parse(text) as MarketAnalysis;

  } catch (error) {
    console.error("Error analyzing market:", error);
    return {
      sentiment: 'neutral',
      summary: 'El servicio de análisis no está disponible en este momento.',
      keyLevels: 'Intente más tarde.'
    };
  }
};