
import { CoinData, Currency, DataSource } from '../types';

export const CURRENCY_SYMBOLS: Record<Currency, string> = {
  USD: '$',
  EUR: '€'
};

const FALLBACK_RATES: Record<Currency, number> = {
  USD: 1,
  EUR: 0.92
};

// Known configurations for better UX (Names and Colors)
// For unknown coins, we will generate defaults
const KNOWN_COINS: Record<string, { name: string, color: string }> = {
  'BTC': { name: 'Bitcoin', color: '#F7931A' },
  'ETH': { name: 'Ethereum', color: '#627EEA' },
  'XRP': { name: 'Ripple', color: '#FFFFFF' },
  'SOL': { name: 'Solana', color: '#14F195' },
  'ADA': { name: 'Cardano', color: '#0033AD' },
  'DOGE': { name: 'Dogecoin', color: '#C2A633' },
  'BNB': { name: 'BNB', color: '#F3BA2F' },
  'DOT': { name: 'Polkadot', color: '#E6007A' },
  'TFUEL': { name: 'Theta Fuel', color: '#E58E26' },
};

// Helper to generate a consistent color for unknown coins based on string hash
const getColorForSymbol = (symbol: string): string => {
  if (KNOWN_COINS[symbol]) return KNOWN_COINS[symbol].color;
  
  const colors = ['#EF4444', '#F59E0B', '#10B981', '#3B82F6', '#6366F1', '#8B5CF6', '#EC4899'];
  let hash = 0;
  for (let i = 0; i < symbol.length; i++) {
    hash = symbol.charCodeAt(i) + ((hash << 5) - hash);
  }
  return colors[Math.abs(hash) % colors.length];
};

const generateHistory = (basePrice: number, points: number = 24) => {
  const history = [];
  let price = basePrice;
  for (let i = 0; i < points; i++) {
    const time = new Date(Date.now() - (points - i) * 3600000).getHours() + ':00';
    const change = (Math.random() - 0.5) * (basePrice * 0.02);
    price += change;
    history.push({ time, price });
  }
  return history;
};

// Get initial data based on requested symbols
export const getInitialData = (currency: Currency = 'USD', symbols: string[] = ['BTC', 'ETH', 'XRP']): CoinData[] => {
  const rate = FALLBACK_RATES[currency];
  
  return symbols.map((symbol) => {
    const config = KNOWN_COINS[symbol] || { name: symbol, color: getColorForSymbol(symbol) };
    const price = (Math.random() * 1000 + 10) * rate;
    
    return {
      id: symbol.toLowerCase(),
      symbol: symbol,
      name: config.name,
      currentPrice: price,
      change24h: (Math.random() * 4) - 2,
      history: generateHistory(price),
      color: config.color
    };
  });
};

// --- API FETCHERS ---

// 1. Kraken Fetcher (Single Symbol)
const fetchKrakenDataSingle = async (symbol: string, currency: Currency): Promise<CoinData | null> => {
    const krakenSuffix = currency; // Kraken uses 'USD' or 'EUR' directly usually
    const pair = `${symbol}${krakenSuffix}`;
    
    try {
        // Fetch Ticker
        const tickerRes = await fetch(`https://api.kraken.com/0/public/Ticker?pair=${pair}`);
        const tickerJson = await tickerRes.json();
        
        if (tickerJson.error && tickerJson.error.length > 0) return null;
        
        const resultKeys = Object.keys(tickerJson.result);
        if (resultKeys.length === 0) return null;
        
        const data = tickerJson.result[resultKeys[0]];
        const currentPrice = parseFloat(data.c[0]);
        const openPrice = parseFloat(data.o); // 'o' is today's opening price
        const change24h = openPrice > 0 ? ((currentPrice - openPrice) / openPrice) * 100 : 0;
        
        // Fetch History (OHLC)
        let history = [];
        try {
             // 60 minute interval = 1 hour
             const ohlcRes = await fetch(`https://api.kraken.com/0/public/OHLC?pair=${pair}&interval=60`);
             const ohlcJson = await ohlcRes.json();
             if (!ohlcJson.error || ohlcJson.error.length === 0) {
                 const ohlcKeys = Object.keys(ohlcJson.result).filter(k => k !== 'last');
                 const ticks = ohlcJson.result[ohlcKeys[0]]; 
                 // Format: [time, open, high, low, close, vwap, volume, count]
                 // Take last 24
                 const last24 = ticks.slice(-24);
                 history = last24.map((t: any) => ({
                     time: new Date(t[0] * 1000).getHours() + ':00',
                     price: parseFloat(t[4])
                 }));
             }
        } catch (e) {
            history = generateHistory(currentPrice);
        }
        
        if (history.length === 0) history = generateHistory(currentPrice);

        const config = KNOWN_COINS[symbol] || { name: symbol, color: getColorForSymbol(symbol) };

        return {
            id: symbol.toLowerCase(),
            symbol: symbol,
            name: config.name,
            currentPrice,
            change24h,
            history,
            color: config.color
        };

    } catch (e) {
        console.warn(`Kraken fetch failed for ${symbol}:`, e);
        return null;
    }
}

// 2. Kraken Batch Wrapper
const fetchKrakenBatch = async (currency: Currency, symbols: string[]): Promise<CoinData[]> => {
    const promises = symbols.map(s => fetchKrakenDataSingle(s, currency));
    const results = await Promise.all(promises);
    return results.filter((r): r is CoinData => r !== null);
};

// 3. Binance Batch Fetcher
const fetchBinanceBatch = async (currency: Currency, symbols: string[]): Promise<CoinData[]> => {
    const foundData: CoinData[] = [];
    const binanceSuffix = currency === 'USD' ? 'USDT' : 'EUR';
    
    // Map: "BTCUSDT" -> "BTC"
    const symbolMapping: Record<string, string> = {};
    const binanceSymbols: string[] = [];

    symbols.forEach(sym => {
      const binanceSymbol = `${sym.toUpperCase()}${binanceSuffix}`;
      binanceSymbols.push(binanceSymbol);
      symbolMapping[binanceSymbol] = sym;
    });

    try {
        const symbolsParam = JSON.stringify(binanceSymbols);
        const tickerResponse = await fetch(`https://api.binance.com/api/v3/ticker/24hr?symbols=${symbolsParam}`);
        
        if (!tickerResponse.ok) return [];

        const tickerData = await tickerResponse.json();
        
        // Process each coin found in Binance
        const coinPromises = tickerData.map(async (ticker: any) => {
            const binanceSymbol = ticker.symbol;
            const originalSymbol = symbolMapping[binanceSymbol];
            
            if (!originalSymbol) return null;

            const config = KNOWN_COINS[originalSymbol] || { name: originalSymbol, color: getColorForSymbol(originalSymbol) };
            
            // Fetch Klines
            let history = [];
            try {
                const klinesResponse = await fetch(`https://api.binance.com/api/v3/klines?symbol=${binanceSymbol}&interval=1h&limit=24`);
                if (klinesResponse.ok) {
                    const klinesData = await klinesResponse.json();
                    history = klinesData.map((item: any) => ({
                        time: new Date(item[0]).getHours() + ':00',
                        price: parseFloat(item[4])
                    }));
                } else {
                    history = generateHistory(parseFloat(ticker.lastPrice));
                }
            } catch (e) {
                history = generateHistory(parseFloat(ticker.lastPrice));
            }

            return {
                id: originalSymbol.toLowerCase(),
                symbol: originalSymbol,
                name: config.name,
                currentPrice: parseFloat(ticker.lastPrice),
                change24h: parseFloat(ticker.priceChangePercent),
                history: history,
                color: config.color
            };
        });

        const binanceResults = await Promise.all(coinPromises);
        binanceResults.forEach(r => {
            if (r) foundData.push(r);
        });

    } catch (error) {
        console.warn("Binance batch fetch failed", error);
    }
    
    return foundData;
};

// --- MAIN FETCH FUNCTION ---

export const fetchCryptoData = async (currency: Currency, symbols: string[], dataSource: DataSource = 'BINANCE'): Promise<CoinData[]> => {
  if (symbols.length === 0) return [];

  const finalData: CoinData[] = [];
  const fetchedSymbols = new Set<string>();

  // Helper to process results
  const processResults = (results: CoinData[]) => {
      results.forEach(r => {
          if (!fetchedSymbols.has(r.symbol)) {
              finalData.push(r);
              fetchedSymbols.add(r.symbol);
          }
      });
  };

  // 1. Primary Source
  if (dataSource === 'BINANCE') {
      const binanceResults = await fetchBinanceBatch(currency, symbols);
      processResults(binanceResults);
  } else {
      const krakenResults = await fetchKrakenBatch(currency, symbols);
      processResults(krakenResults);
  }

  // 2. Identify Missing
  const missingSymbols = symbols.filter(s => !fetchedSymbols.has(s));

  // 3. Secondary Source (Fallback)
  if (missingSymbols.length > 0) {
      if (dataSource === 'BINANCE') {
          // Fallback to Kraken
          const krakenResults = await fetchKrakenBatch(currency, missingSymbols);
          processResults(krakenResults);
      } else {
          // Fallback to Binance
          const binanceResults = await fetchBinanceBatch(currency, missingSymbols);
          processResults(binanceResults);
      }
  }
  
  // 4. Fallback for completely failed (Mock)
  const stillMissing = symbols.filter(s => !fetchedSymbols.has(s));
  if (stillMissing.length > 0) {
      const mockData = getInitialData(currency, stillMissing);
      processResults(mockData);
  }

  // Return data in the same order as requested symbols
  const orderedData = symbols.map(sym => finalData.find(d => d.symbol === sym)).filter((d): d is CoinData => !!d);

  return orderedData;
};

export const formatPrice = (price: number, currency: Currency): string => {
  return new Intl.NumberFormat(currency === 'EUR' ? 'es-ES' : 'en-US', {
    style: 'currency',
    currency: currency,
    minimumFractionDigits: 2,
    maximumFractionDigits: 6 
  }).format(price);
};
